Documentation
=============

This directory does _not_ contain documentation for HTML Tidy. It consists of files used for generating documentation for HTML Tidy.

Please consult the main README file for more information.
