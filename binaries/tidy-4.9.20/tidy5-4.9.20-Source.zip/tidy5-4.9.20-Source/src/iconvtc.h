#ifndef __ICONVTC_H__
#define __ICONVTC_H__
#ifdef TIDY_ICONV_SUPPORT

/* iconvtc.h -- Interface to iconv transcoding routines

  (c) 1998-2003 (W3C) MIT, ERCIM, Keio University
  See tidy.h for the copyright notice.

*/


#endif /* TIDY_ICONV_SUPPORT */
#endif /* __ICONVTC_H__ */
